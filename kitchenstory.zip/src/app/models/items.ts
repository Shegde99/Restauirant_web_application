export class Items {
    id!: number;
    title!: string;
    description!: string;
    category!: string;
    image!:string;
    price!:number;
}
