export class Visitor {
        name!:string;
        email!:string;
        contact!:string;
    }
